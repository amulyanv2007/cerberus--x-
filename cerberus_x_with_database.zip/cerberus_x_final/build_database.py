# CERBERUS-X - BUILD THE DATABASE (SQLite)
# Job: take the robot's notebook (output/claims.csv) and store everything
#      in ONE database file:  output/cerberus.db
# SQLite is built into Python, so nothing extra to install.
#
# Run:  py build_database.py   (it runs the reader first if needed)

import os, sqlite3, subprocess, sys
import pandas as pd

BASE = os.path.dirname(os.path.abspath(__file__))
CSV = os.path.join(BASE, "output", "claims.csv")
DB = os.path.join(BASE, "output", "cerberus.db")

if not os.path.exists(CSV):
    subprocess.run([sys.executable, os.path.join(BASE, "ingest_simple.py")], check=True,
                   stdout=subprocess.DEVNULL)
claims = pd.read_csv(CSV).fillna("")
if "claim_id" not in claims.columns:      # give every clue an ID card: C01, C02...
    claims.insert(0, "claim_id", [f"C{i+1:02d}" for i in range(len(claims))])

# Same names the reader uses (many names -> one person)
ALIASES = {"Tom Sharma": ["Tom Sharma", "T. Sharma", "Tommy S.", "Tom"]}

if os.path.exists(DB):
    os.remove(DB)                       # start fresh each time
con = sqlite3.connect(DB)
cur = con.cursor()

# ---------------- 1. Tables ----------------
cur.executescript("""
CREATE TABLE sources (
    source_id   INTEGER PRIMARY KEY,
    file_name   TEXT UNIQUE NOT NULL,
    modality    TEXT NOT NULL,          -- text / table / scan
    base_trust  REAL NOT NULL           -- 0 to 1
);
CREATE TABLE entities (
    entity_id      INTEGER PRIMARY KEY,
    canonical_name TEXT UNIQUE NOT NULL,
    kind           TEXT NOT NULL        -- person / place
);
CREATE TABLE aliases (
    alias_id  INTEGER PRIMARY KEY,
    entity_id INTEGER NOT NULL REFERENCES entities(entity_id),
    alias     TEXT NOT NULL
);
CREATE TABLE claims (
    claim_id    TEXT PRIMARY KEY,
    entity_id   INTEGER REFERENCES entities(entity_id),   -- NULL if no person
    subject_raw TEXT,
    relation    TEXT NOT NULL,
    value       TEXT,
    source_id   INTEGER NOT NULL REFERENCES sources(source_id),
    trust       REAL NOT NULL,
    status      TEXT NOT NULL,          -- used / ignored_fake / ignored_weird / other_time
    note        TEXT
);
CREATE TABLE conflicts (
    conflict_id INTEGER PRIMARY KEY,
    entity_id   INTEGER NOT NULL REFERENCES entities(entity_id),
    question    TEXT NOT NULL,
    winner      TEXT NOT NULL,
    winner_trust REAL NOT NULL,
    loser       TEXT NOT NULL,
    loser_trust  REAL NOT NULL
);
CREATE VIEW v_trust_by_place AS
    SELECT e.canonical_name AS person, c.value AS place,
           ROUND(SUM(c.trust), 2) AS total_trust, COUNT(*) AS num_clues
    FROM claims c JOIN entities e ON e.entity_id = c.entity_id
    WHERE c.status = 'used'
    GROUP BY e.canonical_name, c.value
    ORDER BY total_trust DESC;
""")

# ---------------- 2. Fill: sources ----------------
for src, grp in claims.groupby("source"):
    cur.execute("INSERT INTO sources(file_name, modality, base_trust) VALUES (?,?,?)",
                (src, grp["type"].iloc[0], float(grp["trust"].max())))
source_id = dict(cur.execute("SELECT file_name, source_id FROM sources").fetchall())

# ---------------- 3. Fill: entities + aliases ----------------
for name, names in ALIASES.items():
    cur.execute("INSERT INTO entities(canonical_name, kind) VALUES (?, 'person')", (name,))
    eid = cur.lastrowid
    cur.executemany("INSERT INTO aliases(entity_id, alias) VALUES (?,?)", [(eid, a) for a in names])
entity_id = dict(cur.execute("SELECT canonical_name, entity_id FROM entities").fetchall())

# ---------------- 4. Fill: claims ----------------
def status_of(row):
    if "FAKE" in row["note"]:  return "ignored_fake"
    if "WEIRD" in row["note"]: return "ignored_weird"
    if row["where"] == "school": return "other_time"   # school row is about 9 AM, not 5 PM
    return "used"

for _, r in claims.iterrows():
    cur.execute("INSERT INTO claims VALUES (?,?,?,?,?,?,?,?,?)", (
        r["claim_id"], entity_id.get(r["who"]), r["who"], "was_at", r["where"],
        source_id[r["source"]], float(r["trust"]), status_of(r), r["note"]))

# ---------------- 5. Fill: conflicts ----------------
used = pd.read_sql("SELECT * FROM claims WHERE status='used' AND entity_id IS NOT NULL", con)
for eid, grp in used.groupby("entity_id"):
    totals = grp.groupby("value")["trust"].sum().sort_values(ascending=False)
    if len(totals) > 1:
        win = totals.index[0]
        for lose in totals.index[1:]:
            cur.execute("INSERT INTO conflicts(entity_id, question, winner, winner_trust, loser, loser_trust) "
                        "VALUES (?,?,?,?,?,?)", (int(eid), "Where was the person around 5 PM?",
                        win, round(float(totals[win]), 2), lose, round(float(totals[lose]), 2)))
con.commit()

# ---------------- 6. Show what is inside ----------------
def show(title, sql):
    print(f"\n=== {title} ===")
    print(pd.read_sql(sql, con).to_string(index=False))

print("Database created:", DB)
show("SOURCES (who gave the clues, and trust)", "SELECT file_name, modality, base_trust FROM sources")
show("TRUST BY PLACE (view)", "SELECT * FROM v_trust_by_place")
show("CONFLICTS FOUND", """SELECT e.canonical_name AS person, c.winner, c.winner_trust, c.loser, c.loser_trust
                           FROM conflicts c JOIN entities e USING(entity_id)""")
show("IGNORED CLUES", """SELECT c.claim_id, s.file_name, c.status, c.note FROM claims c
                         JOIN sources s USING(source_id) WHERE c.status != 'used'""")
con.close()
