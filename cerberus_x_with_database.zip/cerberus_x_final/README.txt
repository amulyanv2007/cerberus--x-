CERBERUS-X - How to run
1. Extract this zip (right-click > Extract All).
2. Double-click RUN_ME.bat   (needs Python installed, with "Add to PATH")
   OR open the folder in VS Code, open the terminal and type:  py ingest_simple.py
3. Take a screenshot of the table.
Optional: install Tesseract (UB-Mannheim) so the scan is read live by OCR.

NEW: Clue map
   py clue_map.py   ->  creates output/clue_map.png
   (RUN_ME.bat now runs both steps and opens the picture)

NEW: Database
   py build_database.py  ->  creates output/cerberus.db (SQLite, nothing extra to install)
   Tables: sources, entities, aliases, claims, conflicts + view v_trust_by_place
