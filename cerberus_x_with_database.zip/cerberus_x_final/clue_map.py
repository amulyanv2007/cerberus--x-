# CERBERUS-X - CLUE MAP (Knowledge Graph)
# Dots = person, places, documents.  Lines = "this document says Tom was here".
# RED dashed line = the clues disagree (CONFLICT).
#
# Run:  py clue_map.py      (it runs the reader first if needed)

import os, subprocess, sys
import pandas as pd
import networkx as nx
import matplotlib
matplotlib.use("Agg")                     # save a picture, no window needed
import matplotlib.pyplot as plt

BASE = os.path.dirname(os.path.abspath(__file__))
CSV = os.path.join(BASE, "output", "claims.csv")

# Step 1: make sure the robot has read the files
if not os.path.exists(CSV):
    subprocess.run([sys.executable, os.path.join(BASE, "ingest_simple.py")], check=True,
                   stdout=subprocess.DEVNULL)
claims = pd.read_csv(CSV).fillna("")

# Step 2: split claims into "good" clues and "ignored" clues
ignored = claims[claims["note"].str.contains("FAKE|WEIRD", regex=True)]
tom = claims[(claims["who"] == "Tom Sharma") & ~claims["note"].str.contains("FAKE|WEIRD", regex=True)]
other_time = tom[tom["where"] == "school"]        # same rule as ingest: school fact is not about 5 PM
tom = tom[tom["where"] != "school"]

# Step 3: build the graph
G = nx.Graph()
G.add_node("Tom Sharma", kind="person")

# group repeated rows from the same file (e.g. attendance.csv has two "home" rows)
groups = tom.groupby(["source", "where"]).agg(trust=("trust", "sum"), n=("trust", "size")).reset_index()
for _, r in groups.iterrows():
    doc = r["source"] if r["n"] == 1 else f'{r["source"]} (x{r["n"]})'
    G.add_node(doc, kind="doc")
    G.add_node(r["where"], kind="place")
    G.add_edge(doc, r["where"], trust=round(r["trust"], 2), kind="says")

totals = tom.groupby("where")["trust"].sum().round(2).sort_values(ascending=False)
for place, t in totals.items():
    G.add_edge("Tom Sharma", place, trust=t, kind="total")

# Step 4: place the dots in a tidy layout
places = list(totals.index)                                   # most trusted first
pos = {"Tom Sharma": (0, 3)}
xs = {p: (i - (len(places) - 1) / 2) * 6 for i, p in enumerate(places)}
for p in places:
    pos[p] = (xs[p], 1.5)
    docs = [n for n in G.neighbors(p) if G.nodes[n]["kind"] == "doc"]
    for j, d in enumerate(docs):
        pos[d] = (xs[p] + (j - (len(docs) - 1) / 2) * 3.2, 0)

# Step 5: draw
fig, ax = plt.subplots(figsize=(13, 8))
winner = places[0] if places else None
colors, sizes = [], []
for n in G.nodes:
    k = G.nodes[n]["kind"]
    if k == "person": colors.append("#7B61FF"); sizes.append(4200)
    elif k == "place": colors.append("#2E9E5B" if n == winner else "#F0A030"); sizes.append(3600)
    else: colors.append("#9CC9F5"); sizes.append(3000)

nx.draw_networkx_nodes(G, pos, node_color=colors, node_size=sizes, ax=ax, edgecolors="#333333")
nx.draw_networkx_edges(G, pos, edgelist=[e for e in G.edges if G.edges[e]["kind"] == "says"],
                       edge_color="#555555", width=2, ax=ax)
nx.draw_networkx_edges(G, pos, edgelist=[e for e in G.edges if G.edges[e]["kind"] == "total"],
                       edge_color="#7B61FF", width=[1 + G.edges[e]["trust"] * 1.5 for e in G.edges if G.edges[e]["kind"] == "total"], ax=ax)
nx.draw_networkx_labels(G, pos, font_size=9, font_weight="bold", ax=ax)
nx.draw_networkx_edge_labels(G, pos, ax=ax, font_size=9, font_color="#222222",
    edge_labels={e: (f'trust {G.edges[e]["trust"]}' if G.edges[e]["kind"] == "says"
                     else f'total {G.edges[e]["trust"]}') for e in G.edges})

# the conflict line
if len(places) > 1:
    (x1, y1), (x2, y2) = pos[places[0]], pos[places[1]]
    ax.annotate("", xy=(x2, y2 + 0.02), xytext=(x1, y1 + 0.02),
                arrowprops=dict(arrowstyle="<->", color="red", lw=3, linestyle="--", shrinkA=34, shrinkB=34))
    ax.text((x1 + x2) / 2, y1 + 0.28, "CONFLICT", color="red", fontsize=14, fontweight="bold", ha="center")

# ignored clues (not connected to Tom)
notes = []
for _, r in ignored.iterrows():
    notes.append(f'IGNORED: {r["source"]}  ({"fake / trick note" if "FAKE" in r["note"] else "weird value"})')
for _, r in other_time.drop_duplicates("source").iterrows():
    notes.append(f'NOT USED: {r["source"]} school row  (a different time of day, not 5 PM)')
ax.text(0.01, 0.02, "\n".join(notes), transform=ax.transAxes, fontsize=9, color="#B00020",
        va="bottom", bbox=dict(boxstyle="round", fc="#FFF0F0", ec="#B00020"))

if winner:
    ax.set_title(f"CERBERUS-X Clue Map: where was Tom Sharma around 5 PM?\n"
                 f"Most trusted answer: '{winner}'   (green = winner, orange = loser, blue = documents)",
                 fontsize=13, fontweight="bold")
ax.set_xlim(-8.5, 8.5); ax.set_ylim(-0.9, 3.6); ax.axis("off")
out = os.path.join(BASE, "output", "clue_map.png")
plt.tight_layout(); plt.savefig(out, dpi=140); plt.close()
print("Clue map saved to:", out)
print("Trust totals:", dict(totals))
