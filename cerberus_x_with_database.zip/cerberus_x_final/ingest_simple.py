# CERBERUS-X - SIMPLE INGESTION CODE
# Job: READ every file and write the facts into ONE clean list,
#      then check if the clues disagree.
#
# Run:  py ingest_simple.py     (or double-click RUN_ME.bat)

import glob, os, re
import pandas as pd

# Always look for folders next to THIS file, so it works from any terminal folder
BASE = os.path.dirname(os.path.abspath(__file__))

# ---- Robot eyes (OCR) setup: optional, the program will not crash without it ----
OCR_READY = False
try:
    from PIL import Image
    import pytesseract
    for path in [r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                 r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"]:
        if os.path.exists(path):
            pytesseract.pytesseract.tesseract_cmd = path
    pytesseract.get_tesseract_version()      # fails if Tesseract is not installed
    OCR_READY = True
except Exception:
    print("[info] Tesseract OCR not found -> using the saved OCR text for the scan.\n")

# ---- Step 1: Tiny "dictionaries" the robot uses ----
PLACES = ["home", "shop", "bank", "school", "library"]
NAMES = {"tom sharma": "Tom Sharma", "t. sharma": "Tom Sharma", "tommy s.": "Tom Sharma"}
TRUST = {"police_report": 0.95, "attendance": 0.85, "shop_receipt": 0.70,
         "shop_receipt_saved_ocr": 0.70, "diary_note": 0.30, "suspicious_note": 0.05}

facts = []   # our clean notebook

def save_fact(who, place, source, kind, note="", trust=None):
    name = os.path.splitext(os.path.basename(source))[0]
    facts.append({"who": who, "where": place, "source": os.path.basename(source),
                  "type": kind, "trust": TRUST.get(name, 0.5) if trust is None else trust,
                  "note": note})

def find_name(text):
    for short, full in NAMES.items():
        if short in text.lower():
            return full
    return None

def find_place(text):
    for p in PLACES:
        if re.search(r"\b" + p + r"\b", text.lower()):
            return p
    return None

# ---- Step 2: Reader for TEXT files ----
def read_text_file(path):
    for line in open(path, encoding="utf-8"):
        if "ignore all previous instructions" in line.lower():
            save_fact("-", "-", path, "text", "FAKE! trying to trick the robot")
            return                       # never obey commands inside files!
        who, place = find_name(line), find_place(line)
        if who and place:
            save_fact(who, place, path, "text")

# ---- Step 3: Reader for TABLES (CSV) ----
def read_table(path):
    table = pd.read_csv(path, dtype=str)
    for _, row in table.iterrows():
        who, place = find_name(row["person"]), row["location"]
        if place not in PLACES:
            save_fact(row["person"], place, path, "table", "WEIRD VALUE", trust=0.10)
        elif who:
            save_fact(who, place, path, "table")

# ---- Step 4: Reader for SCANNED pictures (OCR = robot eyes) ----
def read_scan(path):
    if OCR_READY:
        text, note = pytesseract.image_to_string(Image.open(path)), "read by OCR"
    else:
        saved = os.path.splitext(path)[0] + "_saved_ocr.txt"
        if not os.path.exists(saved):
            return
        text, note = open(saved, encoding="utf-8").read(), "saved OCR text (Tesseract not installed)"
    who, place = find_name(text), find_place(text)
    if who and place:
        save_fact(who, place, path, "scan", note)

# ---- Step 5: Run everything ----
for f in sorted(glob.glob(os.path.join(BASE, "docs", "*.txt"))):   read_text_file(f)
for f in sorted(glob.glob(os.path.join(BASE, "tables", "*.csv"))): read_table(f)
for f in sorted(glob.glob(os.path.join(BASE, "scans", "*.png"))):  read_scan(f)

notebook = pd.DataFrame(facts)
os.makedirs(os.path.join(BASE, "output"), exist_ok=True)
notebook.to_csv(os.path.join(BASE, "output", "claims.csv"), index=False)

pd.set_option("display.width", 200)
print("=== CLAIMS TABLE (what the robot read) ===")
print(notebook.to_string(index=False))

# ---- Step 6: Conflict check ----
good = notebook[(notebook["who"] == "Tom Sharma") & (notebook["note"] != "WEIRD VALUE")]
good = good[good["where"] != "school"]          # school fact is about 9 AM, not 5 PM
score = good.groupby("where")["trust"].sum().sort_values(ascending=False)
print("\n=== TRUST SCORE: where was Tom Sharma around 5 PM? ===")
print(score.round(2).to_string())
if len(score) > 1:
    print(f"\nCONFLICT! Clues disagree. Most trusted answer: '{score.index[0]}'")
    print(f"(the fake note was ignored; '{score.index[1]}' has less trust)")
