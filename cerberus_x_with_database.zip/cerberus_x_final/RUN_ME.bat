@echo off
cd /d "%~dp0"
py -m pip install -r requirements.txt
py ingest_simple.py
py clue_map.py
py build_database.py
start "" output\clue_map.png
pause
